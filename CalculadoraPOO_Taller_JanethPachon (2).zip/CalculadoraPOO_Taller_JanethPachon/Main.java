import java.util.InputMismatchException;

public class Main {
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();
        UI ui = new UI();
        Historial historial = new Historial();
        char continuar;

        try {
            double n1 = ui.leerNumero("Ingrese el primer número: ");
            char operacion = ui.leerOperacion();
            Operacion op;

            if (operacion == 'r') {
                op = new RaizCuadrada(n1);
            } else {
                double n2 = ui.leerNumero("Ingrese el segundo número: ");
                switch (operacion) {
                    case '+': op = new Suma(n1, n2); break;
                    case '-': op = new Resta(n1, n2); break;
                    case '*': op = new Multiplicacion(n1, n2); break;
                    case '/': op = new Division(n1, n2); break;
                    case '^': op = new Potenciacion(n1, n2); break;
                    case '%': op = new Porcentaje(n1, n2); break;
                    default:
                        System.out.println("Operación no válida.");
                        return;
                }
            }
            double resultado = calculadora.ejecutarOperacion(op);
            historial.agregarRegistro(op.toString());
            System.out.println("Resultado: " + resultado);
        } catch (InputMismatchException e) {
            System.out.println("Entrada no válida. Por favor, ingrese un número.");
        } catch (ArithmeticException | IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
        do {
            continuar = ui.continuar();
            if (continuar == 's') {
                try{
                    double n1 = ui.leerNumero("Ingrese el primer número: ");
                    char operacion = ui.leerOperacion();
                    Operacion op;

                    if (operacion == 'r') {
                        op = new RaizCuadrada(n1);
                    } else {
                        double n2 = ui.leerNumero("Ingrese el segundo número: ");
                        switch (operacion) {
                            case '+': op = new Suma(n1, n2); break;
                            case '-': op = new Resta(n1, n2); break;
                            case '*': op = new Multiplicacion(n1, n2); break;
                            case '/': op = new Division(n1, n2); break;
                            case '^': op = new Potenciacion(n1, n2); break;
                            case '%': op = new Porcentaje(n1, n2); break;
                            default:
                                System.out.println("Operación no válida.");
                                return;
                        }
                    }
                    double resultado = calculadora.ejecutarOperacion(op);
                    historial.agregarRegistro(op.toString());
                    System.out.println("Resultado: " + resultado);
                } catch (InputMismatchException e) {
                    System.out.println("Entrada no válida. Por favor, ingrese un número.");
                } catch (ArithmeticException | IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        } while (continuar == 's');
        historial.mostrarHistorial();
        historial.guardarHistorial();
    }
}