public abstract class Operacion {
    protected double numero1;
    protected double numero2;
    protected String nombreOperacion;

    public Operacion(double numero1, double numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    public String getNombreOperacion() {
        return nombreOperacion;
    }

    public abstract double calcular();

    @Override
    public String toString() {
        return nombreOperacion + ": Resultado = " + calcular();
    }
}