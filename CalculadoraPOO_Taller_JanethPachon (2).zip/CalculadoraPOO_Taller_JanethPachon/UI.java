import java.util.Scanner;

public class UI {
    private Scanner scanner = new Scanner(System.in);

    public double leerNumero(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextDouble();
    }

    public char leerOperacion() {
        System.out.println("Seleccione operación (+, -, *, /, ^, %, r): ");
        return scanner.next().charAt(0);
    }
    public char continuar() {
        System.out.println(" Desea continuar? (s/n): ");
        return scanner.next().charAt(0);
    }
}