public class Resta extends Operacion {
    public Resta(double numero1, double numero2) {
        super(numero1, numero2);
        this.nombreOperacion = "Resta";
    }

    @Override
    public double calcular() {
        return numero1 - numero2;
    }

    @Override
    public String toString() {
        return "Resta: " + numero1 + " - " + numero2 + " = " + calcular();
    }
}