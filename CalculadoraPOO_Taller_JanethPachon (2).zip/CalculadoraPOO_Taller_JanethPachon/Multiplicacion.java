public class Multiplicacion extends Operacion {
    public Multiplicacion(double numero1, double numero2) {
        super(numero1, numero2);
        this.nombreOperacion = "Multiplicación";
    }

    @Override
    public double calcular() {
        return numero1 * numero2;
    }

    @Override
    public String toString() {
        return "Multiplicación: " + numero1 + " * " + numero2 + " = " + calcular();
    }
}