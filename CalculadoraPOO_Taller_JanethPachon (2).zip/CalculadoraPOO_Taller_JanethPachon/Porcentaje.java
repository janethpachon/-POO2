public class Porcentaje extends Operacion {
    public Porcentaje(double numero1, double numero2) {
        super(numero1, numero2);
        this.nombreOperacion = "Porcentaje";
    }

    @Override
    public double calcular() {
        return (numero1 / 100.0) * numero2;
    }

    @Override
    public String toString() {
        return "Porcentaje: " + numero1 + "% de " + numero2 + " = " + calcular();
    }
}