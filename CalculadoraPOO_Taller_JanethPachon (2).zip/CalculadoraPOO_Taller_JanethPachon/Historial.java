import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Historial {
    private List<String> historial = new ArrayList<>();

    public void agregarRegistro(String registro) {
        LocalDateTime ahora = LocalDateTime.now();// obtiene la fecha y hora actual
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"); // define el formato de la fecha
        String fechaHora = ahora.format(formato);// convierte la fecha en texto legible
        historial.add("[" + fechaHora + "] " + registro); // agrega la operación con timestamp
    }

    public void mostrarHistorial() {
        for (String registro : historial) {
            System.out.println(registro);
        }
    }

    public void guardarHistorial() {
    try (FileWriter writer = new FileWriter("historial.txt", true)) { // ← modo acumulativo
        for (String registro : historial) {
            writer.write(registro + "\n");
        }
    } catch (IOException e) {
        System.out.println("Error al guardar el historial: " + e.getMessage());
    }
}
}