public class RaizCuadrada extends Operacion {
    public RaizCuadrada(double numero1) {
        super(numero1, 0);
        this.nombreOperacion = "Raíz Cuadrada";
    }

    @Override
    public double calcular() {
        if (numero1 < 0) throw new IllegalArgumentException("No se puede calcular la raíz cuadrada de un número negativo");
        return Math.sqrt(numero1);
    }

    @Override
    public String toString() {
        return "Raíz Cuadrada: √" + numero1 + " = " + calcular();
    }
}