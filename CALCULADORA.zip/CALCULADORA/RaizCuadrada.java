public class RaizCuadrada extends Operacion implements Registrable {
    public RaizCuadrada(double numero1) {
        super(numero1, 0); // numero2 se ignora
        this.nombreOperacion = "Raíz Cuadrada";
    }

    @Override
    public double calcular() {
        if (numero1 < 0) {
            throw new IllegalArgumentException("El número no puede ser negativo");
        }
        return Math.sqrt(numero1);
    }

    @Override
    public void registrarHistorial() {
        System.out.println("[Raíz Cuadrada] Operación: √" + numero1 + " = " + calcular());
    }
}
