public class Calculadora {
    public double ejecutarOperacion(Operacion operacion){
        double resultado = operacion.calcular();
        System.out.println("Operación: " + operacion.getNombreOperacion());
        return resultado;
    }
}
