public class Division extends Operacion implements Registrable {
    public Division(double numero1, double numero2){
        super(numero1, numero2);
        this.nombreOperacion = "División";
    }

    @Override
    public double calcular(){
        if (numero2 == 0) {
            throw new ArithmeticException("No se puede dividir entre cero");
        }
        return numero1 / numero2;
    }

    @Override
    public void registrarHistorial() {
        System.out.println("[División] Operación: " + numero1 + " / " + numero2 + " = " + calcular());
    }
}