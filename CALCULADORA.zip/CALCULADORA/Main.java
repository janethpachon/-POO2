import java.util.InputMismatchException;

public class Main {
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();
        UI ui = new UI();
        Historial historial = new Historial();

        try {
            double n1 = ui.leerNumero("Ingrese el primer número: ");
            double n2 = ui.leerNumero("Ingrese el segundo número: ");
            char operacion = ui.leerOperacion();

            Operacion op;

            switch (operacion) {
                case '+':
                    op = new Suma(n1, n2);
                    break;
                case '-':
                    op = new Resta(n1, n2);
                    break;
                case '*':
                    op = new Multiplicacion(n1, n2);
                    break;
                case '/':
                    op = new Division(n1, n2);
                    break;
                case '^':
                    op = new Potenciacion(n1, n2);
                    break;
                case '%':
                    op = new Porcentaje(n1, n2);
                    break;
                default:
                    System.out.println("Operación no válida.");
                    return;
            }

            double resultado = calculadora.ejecutarOperacion(op);
            historial.agregarRegistro(op.getNombreOperacion() + ": " + resultado);

            if (op instanceof Registrable) {
                ((Registrable) op).registrarHistorial();
            }

            System.out.println("Resultado: " + resultado);

        } catch (InputMismatchException e) {
            System.out.println("Entrada no válida. Por favor, ingrese un número.");
        } catch (ArithmeticException | IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        historial.mostrarHistorial();
        historial.guardarHistorial();
    }
}

