public class Multiplicacion extends Operacion implements Registrable {
    public Multiplicacion(double numero1, double numero2){
        super(numero1, numero2);
        this.nombreOperacion = "Multiplicación";
    }

    @Override
    public double calcular(){
        return numero1 * numero2;
    }

    @Override
    public void registrarHistorial() {
        System.out.println("[Multiplicación] Operación: " + numero1 + " * " + numero2 + " = " + calcular());
    }
}
