public class Resta extends Operacion implements Registrable {
    public Resta(double numero1, double numero2){
        super(numero1, numero2);
        this.nombreOperacion = "Resta";
    }

    @Override
    public double calcular(){
        return numero1 - numero2;
    }

    @Override
    public void registrarHistorial() {
        System.out.println("[Resta] Operación: " + numero1 + " - " + numero2 + " = " + calcular());
    }
}