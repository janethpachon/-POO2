public class Potenciacion extends Operacion implements Registrable {
    public Potenciacion(double numero1, double numero2) {
        super(numero1, numero2);
        this.nombreOperacion = "Potenciación";
    }

    @Override
    public double calcular() {
        return Math.pow(numero1, numero2);
    }

    @Override
    public void registrarHistorial() {
        System.out.println("[Potenciación] Operación: " + numero1 + " ^ " + numero2 + " = " + calcular());
    }
}