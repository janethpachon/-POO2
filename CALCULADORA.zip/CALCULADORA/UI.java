import java.util.Scanner;

public class UI {
    private Scanner scanner = new Scanner(System.in);

    public double leerNumero(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextDouble();
    }

    public char leerOperacion() {
        System.out.println("Seleccione operación (+, -, *, /, ^, %): ");
        return scanner.next().charAt(0);
    }
}