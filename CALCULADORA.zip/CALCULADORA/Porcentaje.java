public class Porcentaje extends Operacion implements Registrable {
    public Porcentaje(double numero1, double numero2) {
        super(numero1, numero2);
        this.nombreOperacion = "Porcentaje";
    }

    @Override
    public double calcular() {
        return numero1 % numero2;
    }

    @Override
    public void registrarHistorial() {
        System.out.println("[Porcentaje] Operación: " + numero1 + " % " + numero2 + " = " + calcular());
    }
}

