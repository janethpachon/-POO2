
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Historial {
    private List<String> historial = new ArrayList<>();

    public void agregarRegistro(String registro) {
        historial.add(registro);
    }

    public void mostrarHistorial() {
        for (String registro : historial) {
            System.out.println(registro);
        }
    }

    public void guardarHistorial() {
        try (FileWriter writer = new FileWriter("historial.txt")) {
            for (String registro : historial) {
                writer.write(registro + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error al guardar el historial: " + e.getMessage());
        }
    }
}

