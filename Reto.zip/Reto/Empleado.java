public class Empleado {
    
}
