// package empresa.interfaces;

public interface IEmpleado {
    double calcularSalario();
}
