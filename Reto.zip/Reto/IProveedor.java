public interface IProveedor {
    void realizarEntrega();
}