public interface IUsuarioSistema {
    void loguear();
    
}