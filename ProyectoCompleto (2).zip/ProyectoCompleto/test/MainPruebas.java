
package test;

public class MainPruebas {
    public static void main(String[] args) {
        Persona empleadoPersona = new Persona("Juan", "juan@empresa.com");
        Empleado empleado = new Empleado(empleadoPersona);
        empleado.trabajar();

        Persona proveedorPersona = new Persona("Ana", "ana@proveedores.com");
        Proveedor proveedor = new Proveedor(proveedorPersona);
        proveedor.suministrar();

        Persona usuarioPersona = new Persona("Carlos", "carlos@empresa.com");
        UsuarioInterno usuario = new UsuarioInterno(usuarioPersona);
        usuario.accederSistema();
    }
}
