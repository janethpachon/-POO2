package modelo;

public interface UsuarioOperaciones {
    void accederSistema();
}
