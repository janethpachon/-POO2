package modelo;

public interface ProveedorOperaciones {
    void suministrar();
}
