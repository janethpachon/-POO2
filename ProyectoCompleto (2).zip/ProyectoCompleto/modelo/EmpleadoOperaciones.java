
package modelo;

public interface EmpleadoOperaciones {
    void trabajar();
}
