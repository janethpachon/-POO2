package modelo;

public class Empleado {
    private Persona persona;

    public Empleado(Persona persona) {
        this.persona = persona;
    }

    public void trabajar() {
        System.out.println(persona.getNombre() + " está trabajando.");
    }
}
