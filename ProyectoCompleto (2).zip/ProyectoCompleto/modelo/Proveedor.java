
package modelo;

public class Proveedor {
    private Persona persona;

    public Proveedor(Persona persona) {
        this.persona = persona;
    }

    public void suministrar() {
        System.out.println(persona.getNombre() + " está suministrando productos.");
    }
}
