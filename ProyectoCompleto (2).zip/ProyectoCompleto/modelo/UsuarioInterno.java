
package modelo;

public class UsuarioInterno {
    private Persona persona;

    public UsuarioInterno(Persona persona) {
        this.persona = persona;
    }

    public void accederSistema() {
        System.out.println(persona.getNombre() + " está accediendo al sistema.");
    }
}
