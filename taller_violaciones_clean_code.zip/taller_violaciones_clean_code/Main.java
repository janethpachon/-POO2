import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ProductoManager productoManager = new ProductoManager();
        Scanner scanner = new Scanner(System.in);

        boolean continuar = true;
        while (continuar) {
            mostrarMenu();
            int opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> agregarProducto(scanner, productoManager);
                case 2 -> productoManager.mostrarProductos();
                case 3 -> buscarProducto(scanner, productoManager);
                case 4 -> eliminarProducto(scanner, productoManager);
                case 5 -> {
                    System.out.println("Gracias por usar el sistema.");
                    continuar = false;
                }
                default -> System.out.println("Opción inválida.");
            }
        }
    }

    private static void mostrarMenu() {
        System.out.println("""
                1. Agregar producto
                2. Ver productos
                3. Buscar producto por ID
                4. Eliminar producto por ID
                5. Salir
                """);
        System.out.print("Seleccione una opción: ");
    }

    private static void agregarProducto(Scanner scanner, ProductoManager manager) {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Precio: ");
        double precio = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Categoría: ");
        String categoria = scanner.nextLine();

        manager.agregarProducto(nombre, precio, categoria);
    }

    private static void buscarProducto(Scanner scanner, ProductoManager manager) {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        Producto producto = manager.buscarProductoPorId(id);
        if (producto != null) {
            System.out.println(producto.getNombre() + " $" + producto.getPrecio());
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private static void eliminarProducto(Scanner scanner, ProductoManager manager) {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        manager.removerProductoPorId(id);
    }
}
