import java.util.ArrayList;
import java.util.List;

public class ProductoManager {
    private List<Producto> productos = new ArrayList<>();
    private int ultimoId = 0;

    public void agregarProducto(String nombre, double precio, String categoria) {
        Producto nuevoProducto = new Producto(ultimoId++, nombre, precio, categoria);
        productos.add(nuevoProducto);
        System.out.println("Producto agregado exitosamente.");
    }

    public void mostrarProductos() {
        for (Producto producto : productos) {
            System.out.println(producto.getId() + " - " + producto.getNombre() + " $" + producto.getPrecio() + " [" + producto.getCategoria() + "]");
        }
    }

    public Producto buscarProductoPorId(int id) {
        for (Producto producto : productos) {
            if (producto.getId() == id) {
                return producto;
            }
        }
        return null;
    }

    public void removerProductoPorId(int id) {
        productos.removeIf(producto -> producto.getId() == id);
        System.out.println("Producto eliminado si existía.");
    }
}
